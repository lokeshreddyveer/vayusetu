const fs=require('fs');const path=require('path');
const sharp=require('/Users/lokeshreddyveerabhadra/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
(async()=>{
 const root=__dirname;
 for(const name of fs.readdirSync(root).filter(x=>x.endsWith('.svg'))){await sharp(path.join(root,name)).png().toFile(path.join(root,name.replace('.svg','-1024.png')));}
 for(const name of fs.readdirSync(path.join(root,'layers')).filter(x=>x.endsWith('.svg'))){await sharp(path.join(root,'layers',name)).png().toFile(path.join(root,'layers',name.replace('.svg','.png')));}
 for(const appearance of ['Default','Dark','Light','Tinted']){
   for(const size of [180,120,60,29])await sharp(path.join(root,`Setu-Stones-${appearance}-1024.png`)).resize(size,size).png().toFile(path.join(root,`previews/${appearance.toLowerCase()}-${size}.png`));
 }
 const labels=['1 · Setu Stones','2 · Vayu Letter','3 · Two Glasses'];const files=['Setu-Stones-Default-1024.png','Vayu-Letter-1024.png','Two-Glasses-1024.png'];
 const overlays=[];
 for(let i=0;i<3;i++)overlays.push({input:await sharp(path.join(root,files[i])).resize(256,256).toBuffer(),left:i*360+52,top:76});
 const text=Buffer.from(`<svg width="1080" height="420" xmlns="http://www.w3.org/2000/svg"><g font-family="Helvetica,Arial" font-size="22" fill="#F0F4F6">${labels.map((label,i)=>`<text x="${i*360+52}" y="44">${label}</text>`).join('')}</g><g font-family="Helvetica,Arial" font-size="16" fill="#B0BDC7"><text x="52" y="370">Wind + stepping stones + packets</text><text x="412" y="370">Devanagari letter + bridge span</text><text x="772" y="370">VPN and DNS overlap</text></g></svg>`);
 overlays.push({input:text,left:0,top:0});
 await sharp({create:{width:1080,height:420,channels:3,background:'#20262D'}}).composite(overlays).png().toFile(path.join(root,'Concept-Comparison.png'));
 console.log('Rendered all concepts, eight separate layers and 16 size previews.');
})().catch(e=>{console.error(e);process.exit(1)});
